clear;
clc;
close all;
%%
% Import the files: control/adj_network_idx
fpi1=fopen('control otu.txt');
hline1 = textscan(fpi1, '%s', 1, 'delimiter', '\n');
field1=textscan(hline1{1}{1},'%s');
clear format;
format1='%s';
% format1=[format1,' %s'];
for i=2:23
    format1=[format1,' %f'];
end
lines1 =textscan(fpi1, format1,1000000,'delimiter', '\t');
genename1=lines1{1};
pprofile1 = [];
for i=2:23
    pprofile1 = [pprofile1, lines1{i}];
end
fclose(fpi1);
fid1=fopen('control idx_edge.txt');
control_network={};
j=0;
while ~feof(fid1)
    tline1=fgetl(fid1);
    j=j+1;
    control_network{j}=regexp(tline1, '\s+', 'split');
end
fclose(fid1);
total_node_num=j;
pprofile=abs(zscore(pprofile1));
psize=size(pprofile);

for i=1:psize(1)
    for j=1:psize(2)
    pprofile11(i,j)=pprofile(i,j)./sum(pprofile(i,:));
    end
end
p_cond=[];
p_node=[];
m=[];
m_=[];
for na=1:total_node_num
     for n=2:length(control_network{na})-1%������������������center���⣩��-1����Ϊ��ȡ�����ĳ��ȱ�ʵ�ʶ�1
        center=control_network{na}{1};
        center=str2num(center);%str2num���ַ�������ַ���ת��Ϊ��ֵ����
        nei=control_network{na}{n};
        ne=str2num(nei);
        v=(pprofile11(center,1:psize(2)))';
        v_=(pprofile11(ne,1:psize(2)))';
        mi=calmi(v,v_,psize(2));
        p_cond(na,n-1)=mi;
        m(na)=abs(geomean(pprofile11(center,1:psize(2))));
        m_(na,n-1)=abs(geomean(pprofile11(ne,1:psize(2))));
     end
end
m=abs(zscore(m));
m_=abs(zscore(m_));
for na=1:total_node_num
     for n=2:length(control_network{na})-1%������������������center���⣩��-1����Ϊ��ȡ�����ĳ��ȱ�ʵ�ʶ�1
        center=control_network{na}{1};
        center=str2num(center);%str2num���ַ�������ַ���ת��Ϊ��ֵ����
        nei=control_network{na}{n};
        ne=str2num(nei);
      for j=1:psize(2) 
         %���������������Ļ�������ϸ���
         p_cond_(na,n-1)=p_cond(na,n-1)./sum(p_cond(na,:));
         p_dis(n-1,j)=(abs(log(abs(pprofile11(center,j)/m(na)))-log(abs(pprofile11(ne,j)/m_(na,n-1)))));
         %p_dis(n-1,j)=abs(pprofile11(center,j)-pprofile11(ne,j))./(pprofile11(center,j)+pprofile11(ne,j));
         p_joint(n-1,j)=p_dis(n-1,j)./sum(p_dis(:,j));
         %���������������Ļ������������
         %p_cond_(na,n-1)=p_cond(na,n-1)./sum(p_cond(na,:));
         p_node(na,n-1)=p_joint(n-1,j)./p_cond_(na,n-1);
         %p_node_(na,n-1)=mean(p_node(na,n-1,:));
         entropy_node(na,n-1)= -sum(p_node(na,n-1).*pprofile11(n-1,j).*log(abs(pprofile11(n-1,j).*(p_node(na,n-1)))));
      end
     end
        entropy(na)=abs(mean(entropy_node(na,:)));
end
entropy=mean(entropy);
%%
fpi2=fopen('E003251 otu.txt');
hline2 = textscan(fpi2, '%s', 1, 'delimiter', '\n');
field2=textscan(hline2{1}{1},'%s');
clear format2;
format2='%s';
% format2=[format2,' %s'];
for i=2:31
    format2=[format2,' %f'];
end
lines2=textscan(fpi2, format2,1000000,'delimiter', '\t');
genename2=lines2{1};
mprofile= [];
for i = 2:31
    mprofile = [mprofile, lines2{i}];
end
fclose(fpi2);

fid3=fopen('E003251 idx_edge.txt');
E003251_network={};
j=0;
while ~feof(fid3)
    tline3=fgetl(fid3);
    j=j+1;
    E003251_network{j}=regexp(tline3, '\s+', 'split');
end
fclose(fid3);
total_node_num1=j;
%mprofile=abs(zscore(mprofile));
psize1=size(mprofile);

%��������
reference_num=22;
stage=8;
tempcase=zeros(psize1(1),23,8);
%ÿ��״̬��22����������+1��case����
%���ݱ�׼��
for t=1:stage
   tempcase(:,1:22,t)=mprofile(:,1:22); 
   tempcase(:,23,t)=mprofile(:,22+t); 
end
tempcase=abs(zscore(tempcase));
msize=size(tempcase);

for i=1:msize(1)
    for j=1:msize(2)
        for k=1:msize(3)
    tempcase1(i,j,k)=tempcase(i,j,k)./sum(tempcase(i,:,k));
    end
    end
end

p_cond1=[];
p_node1=[];
m1=[];
m1_=[];
for t=1:stage
    for na=1:total_node_num1
        for n=2:length(E003251_network{na})-1%������������������center���⣩
        center=E003251_network{na}{1};
        center=str2num(center);%str2num���ַ�������ַ���ת��Ϊ��ֵ����
        nei=E003251_network{na}{n};
        ne=str2num(nei);
        v1=(tempcase1(center,1:msize(2),t))';
        v1_=(tempcase1(ne,1:msize(2),t))';
        mi1=calmi(v1,v1_,msize(2));
        p_cond1(na,n-1,t)=mi1; 
        m1(na)=abs(geomean(tempcase1(center,:,t)));
        m1_(na,n-1)=abs(geomean(tempcase1(ne,:,t)));
end
    end
end
m1=abs(zscore(m1));
m1_=abs(zscore(m1_));
for t=1:stage
    for na=1:total_node_num1
        for n=2:length(E003251_network{na})-1%������������������center���⣩
        center=E003251_network{na}{1};
        center=str2num(center);%str2num���ַ�������ַ���ת��Ϊ��ֵ����
        nei=E003251_network{na}{n};
        ne=str2num(nei);
        for j=1:23
        p_cond11(na,n-1,t)=p_cond1(na,n-1,t)./sum(p_cond1(na,:,t));
        p_dis1(n-1,j,t)=(abs(log(abs(tempcase1(center,j,t)/m1(na)))-log(abs(tempcase1(ne,j,t)/m1_(na,n-1)))));
         %p_dis(n-1,j)=abs(pprofile11(center,j)-pprofile11(ne,j))./(pprofile11(center,j)+pprofile11(ne,j));
         p_joint1(n-1,j,t)=p_dis1(n-1,j,t)./sum(p_dis1(:,j,t));
         %���������������Ļ������������
         %p_cond_(na,n-1)=p_cond(na,n-1)./sum(p_cond(na,:));
         p_node1(na,n-1,t)=p_joint1(n-1,j,t)./p_cond11(na,n-1,t);
         %p_node_(na,n-1)=mean(p_node(na,n-1,:));
         entropy_node1(na,n-1,t)= -sum(p_node1(na,n-1,t).*tempcase1(n-1,j,t).*log(abs(tempcase1(n-1,j,t).*(p_node1(na,n-1,t)))));
         %entropy_node(na,n-1)= -sum(p_node(na,n-1).*pprofile(n-1,j).*exp(pprofile(n-1,j).*(1-p_node(na,n-1))))+es;
        end
        entropy_node11(na,t)=abs(mean(entropy_node1(na,:,t)));
        end
        entropy_node12(t)=mean(entropy_node11(:,t));
        E003251_score(t)=abs(entropy_node12(t)-entropy);
end
end

%%
hsize1=size(entropy_node11);
for i=1:hsize1(1)
    for j=1:hsize1(2)
    entropy_node22(i,j)=entropy_node11(i,j)./sum(entropy_node11(i,:));
    end
end
entropy_node22=abs(zscore(entropy_node22));
[sortgene_idx,indx]=sort(entropy_node22(:,4),'descend');
name1=genename2(1:hsize1);
for t=1:8
  for k=1:hsize1(1)
    sortgene_data(k,t)=entropy_node22(indx(k),t);
  end
  for l=1:hsize1(1)*0.1
    top5gene_data(l,t)=entropy_node22(indx(l),t);
    top5gene_id(l)=name1(indx(l));
  end
end
a=mean((top5gene_data));
E003251_DNB=a./sum(a);
figure('NumberTitle', 'off', 'Name', 'Disturbance Information Gain');
plot([1:1:stage],E003251_DNB,'r','LineWidth',3);
set(gca,'XTick',1:8);
B={ '30' '120' '159' '208' '249' '355' '474' '508'};
set(gca,'XTickLabel',B);
xlabel('time(day)');
ylabel('score');
title('The score of E003251');

